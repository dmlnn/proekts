﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace malininZadacha
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sum = textBox1.Text;
            string srok = textBox2.Text;
            string procent = textBox3.Text;

            int sum1 = Convert.ToInt32(sum);
            int srok1 = Convert.ToInt32(srok);
            int procent1 = Convert.ToInt32(procent);


            int itog = sum1 + (sum1 * procent1 * srok1) / 100 / 12;

            itogoLabel.Text = Convert.ToString(itog);
        }
    }
}
