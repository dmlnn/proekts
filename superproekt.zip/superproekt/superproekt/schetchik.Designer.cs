﻿
namespace superproekt
{
    partial class schetchik
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.грибыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.крупыИКашиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.шоколадToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сырыИТворогToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.напиткиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.фруктыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.трюфелиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.белыеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.лисичкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.рисToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.овсяннаяКашаНаВодеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.гречневаяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.milkiWayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.молочныйШоколадToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.marsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сырМаасдамToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сырЛимбургерToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сырПармезанToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.грибыToolStripMenuItem,
            this.крупыИКашиToolStripMenuItem,
            this.шоколадToolStripMenuItem,
            this.сырыИТворогToolStripMenuItem,
            this.напиткиToolStripMenuItem,
            this.фруктыToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // грибыToolStripMenuItem
            // 
            this.грибыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.трюфелиToolStripMenuItem,
            this.белыеToolStripMenuItem,
            this.лисичкиToolStripMenuItem});
            this.грибыToolStripMenuItem.Name = "грибыToolStripMenuItem";
            this.грибыToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.грибыToolStripMenuItem.Text = "Грибы";
            // 
            // крупыИКашиToolStripMenuItem
            // 
            this.крупыИКашиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.рисToolStripMenuItem,
            this.овсяннаяКашаНаВодеToolStripMenuItem,
            this.гречневаяToolStripMenuItem});
            this.крупыИКашиToolStripMenuItem.Name = "крупыИКашиToolStripMenuItem";
            this.крупыИКашиToolStripMenuItem.Size = new System.Drawing.Size(98, 20);
            this.крупыИКашиToolStripMenuItem.Text = "Крупы и каши";
            // 
            // шоколадToolStripMenuItem
            // 
            this.шоколадToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.milkiWayToolStripMenuItem,
            this.молочныйШоколадToolStripMenuItem,
            this.marsToolStripMenuItem});
            this.шоколадToolStripMenuItem.Name = "шоколадToolStripMenuItem";
            this.шоколадToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.шоколадToolStripMenuItem.Text = "Шоколад";
            // 
            // сырыИТворогToolStripMenuItem
            // 
            this.сырыИТворогToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.сырМаасдамToolStripMenuItem,
            this.сырЛимбургерToolStripMenuItem,
            this.сырПармезанToolStripMenuItem});
            this.сырыИТворогToolStripMenuItem.Name = "сырыИТворогToolStripMenuItem";
            this.сырыИТворогToolStripMenuItem.Size = new System.Drawing.Size(102, 20);
            this.сырыИТворогToolStripMenuItem.Text = "Сыры и творог";
            // 
            // напиткиToolStripMenuItem
            // 
            this.напиткиToolStripMenuItem.Name = "напиткиToolStripMenuItem";
            this.напиткиToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.напиткиToolStripMenuItem.Text = "Напитки";
            // 
            // фруктыToolStripMenuItem
            // 
            this.фруктыToolStripMenuItem.Name = "фруктыToolStripMenuItem";
            this.фруктыToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.фруктыToolStripMenuItem.Text = "Фрукты";
            // 
            // трюфелиToolStripMenuItem
            // 
            this.трюфелиToolStripMenuItem.Name = "трюфелиToolStripMenuItem";
            this.трюфелиToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.трюфелиToolStripMenuItem.Text = "Трюфели";
            // 
            // белыеToolStripMenuItem
            // 
            this.белыеToolStripMenuItem.Name = "белыеToolStripMenuItem";
            this.белыеToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.белыеToolStripMenuItem.Text = "Белые";
            // 
            // лисичкиToolStripMenuItem
            // 
            this.лисичкиToolStripMenuItem.Name = "лисичкиToolStripMenuItem";
            this.лисичкиToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.лисичкиToolStripMenuItem.Text = "Лисички";
            // 
            // рисToolStripMenuItem
            // 
            this.рисToolStripMenuItem.Name = "рисToolStripMenuItem";
            this.рисToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.рисToolStripMenuItem.Text = "Рис";
            // 
            // овсяннаяКашаНаВодеToolStripMenuItem
            // 
            this.овсяннаяКашаНаВодеToolStripMenuItem.Name = "овсяннаяКашаНаВодеToolStripMenuItem";
            this.овсяннаяКашаНаВодеToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.овсяннаяКашаНаВодеToolStripMenuItem.Text = "Овсянная каша на воде";
            // 
            // гречневаяToolStripMenuItem
            // 
            this.гречневаяToolStripMenuItem.Name = "гречневаяToolStripMenuItem";
            this.гречневаяToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.гречневаяToolStripMenuItem.Text = "Гречневая крупа(ядрица)";
            // 
            // milkiWayToolStripMenuItem
            // 
            this.milkiWayToolStripMenuItem.Name = "milkiWayToolStripMenuItem";
            this.milkiWayToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.milkiWayToolStripMenuItem.Text = "MilkiWay";
            // 
            // молочныйШоколадToolStripMenuItem
            // 
            this.молочныйШоколадToolStripMenuItem.Name = "молочныйШоколадToolStripMenuItem";
            this.молочныйШоколадToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.молочныйШоколадToolStripMenuItem.Text = "Молочный шоколад";
            // 
            // marsToolStripMenuItem
            // 
            this.marsToolStripMenuItem.Name = "marsToolStripMenuItem";
            this.marsToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.marsToolStripMenuItem.Text = "Mars";
            // 
            // сырМаасдамToolStripMenuItem
            // 
            this.сырМаасдамToolStripMenuItem.Name = "сырМаасдамToolStripMenuItem";
            this.сырМаасдамToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.сырМаасдамToolStripMenuItem.Text = "Сыр маасдам";
            // 
            // сырЛимбургерToolStripMenuItem
            // 
            this.сырЛимбургерToolStripMenuItem.Name = "сырЛимбургерToolStripMenuItem";
            this.сырЛимбургерToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.сырЛимбургерToolStripMenuItem.Text = "Сыр Лимбургер";
            // 
            // сырПармезанToolStripMenuItem
            // 
            this.сырПармезанToolStripMenuItem.Name = "сырПармезанToolStripMenuItem";
            this.сырПармезанToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.сырПармезанToolStripMenuItem.Text = "Сыр Пармезан";
            // 
            // schetchik
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "schetchik";
            this.Text = "schetchik";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem грибыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem крупыИКашиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem шоколадToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сырыИТворогToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem напиткиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem фруктыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem трюфелиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem белыеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem лисичкиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem рисToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem овсяннаяКашаНаВодеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem гречневаяToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem milkiWayToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem молочныйШоколадToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem marsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сырМаасдамToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сырЛимбургерToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сырПармезанToolStripMenuItem;
    }
}