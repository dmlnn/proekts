﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace vagonimln
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt32(mestoVasi.Text);
            int y = Convert.ToInt32(mestoPetra.Text);
            int k = Convert.ToInt32(kolvoBox.Text);

            int nV = y / k;
            int h = y % k;

            if (h > 0)
            {
                nV = nV + 1; nomerVasi.Text = Convert.ToString(nV);
            }
            else
            {
                nomerVasi.Text = Convert.ToString(nV);
            }
            int nP = x / k;
            int Q = x % k;
            if (Q > 0)
            {
                nP = nP + 1; nomerPetra.Text = Convert.ToString(nP);
            }
            else
            {
                nomerPetra.Text = Convert.ToString(nP);
            }
            if (nP > nV)
            {
                int p = nP - nV; xLabel.Text = Convert.ToString(p);
            }
            else
            {
                int p = nV - nP; xLabel.Text = Convert.ToString(p);
            }
        }
    }
}
